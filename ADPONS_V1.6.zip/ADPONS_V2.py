import select_test_1 as step_1
import extract_orthologous_test_2 as step_2
import megacc_test_3 as step_3
import remove_rogue_and_quality_control_4 as step_4
import realign_and_select_primer_5 as step_5
import conclude_msa_7 as step_6
import os
import argparse


def pipeline(min_exon_len, number_threads, cover, similarity, species_list_path, min_ingroup, min_outgroup, PI_ratio, min_PCR_length, max_PCR_length, min_in_2AA_idtt, min_out_2AA_idtt,
             min_in_idtt, min_total_idtt, max_gap_rate, search_distance,select_scale, out_dir):

    if not os.path.exists(out_dir):
        os.mkdir(out_dir)

    # 输入外显子最小长度、blast线程数、单拷贝的最大覆盖度、单拷贝最大相似度、物种表路径
    pep_cds_path_list = step_1.pipeline(min_exon_len, number_threads, cover, similarity, species_list_path,out_dir)

    # 输入物种表路径、单拷贝peptide fasta文件路径，单拷贝cds fasta文件路径
    step_2.pipeline(species_list_path, pep_cds_path_list[0], pep_cds_path_list[1],out_dir)

    # 输入工作路径和需要align的文件夹
    work_dir = os.path.split(species_list_path)[0]
    align_target_pep_path = os.path.join(out_dir, 'target_peptide')
    align_target_cds_path = os.path.join(out_dir, 'target_cds')
    mao_path = os.path.join(work_dir, 'muscle_align_protein.mao')
    step_3.pipeline(mao_path, align_target_pep_path, out_dir)
    #step_3.pipeline(mao_path, align_target_cds_path, out_dir)

    # 输入需要除流氓的文件夹路径、工作路径、最小内类群数量和最小外类群数量
    rm_rogue7qc_dir = os.path.join(out_dir,'aligned_target_peptide')
    step_4.pipeline(rm_rogue7qc_dir, out_dir, min_ingroup, min_outgroup,select_scale)

    # 输入工作路径、没流氓的对齐矩阵文件夹、PCR与Info分数比例、信号区最小长度、信号区最大长度、内类群2AA最低相似度，外类群2AA最低相似度，内类群引物最低相似度，外类群引物最低相似度，gap最大容忍率、巢式外围引物搜索范围
    primer_source_dir = os.path.join(out_dir,'target_peptide_without_rogue')
    step_5.pipeline(work_dir, primer_source_dir, PI_ratio, min_PCR_length, max_PCR_length, min_in_2AA_idtt, min_out_2AA_idtt,
                    min_in_idtt, min_total_idtt, max_gap_rate, search_distance,out_dir)

    #输出MSA信息表
    step_6.pipeline(out_dir)

#min_exon_len = 300
#number_threads = 10
#cover = 0.3
#min_ingroup = 2
#min_outgroup = 1
#PI_ratio =1
#min_PCR_length = 100
#max_PCR_length = 700
#min_in_2AA_idtt = 1
#min_out_2AA_idtt = 0.9
#min_in_idtt = 0.85
#min_total_idtt = 0.75
#max_gap_rate = 0.3
#search_distance = 150
#select_scale = 1.1
#out_dir = r'E:\PycharmCode\test\taxa1_result'
#pipeline(min_exon_len, number_threads, cover, similarity, species_list_path, min_ingroup,min_outgroup,PI_ratio,min_PCR_length,max_PCR_length,min_in_2AA_idtt,min_out_2AA_idtt,min_in_idtt,min_total_idtt,max_gap_rate,search_distance,select_scale,out_dir)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="python UPrimer_V2.py --list -L")
    parser.add_argument("--list", "-L", help="Your species list", required=True)
    parser.add_argument("--OutDir", "-D", help="Your output directory", required=True)
    parser.add_argument("--MinExonLen", "-E", help="Reference species's min length of single copy peptide", default=int(300))
    parser.add_argument("--threads", "-T", help="Threads used in Blast", default=int(20))
    parser.add_argument("--cover", "-C", help="A criteria when judging single copy exon", default=float(0.3))
    parser.add_argument("--similarity", "-S", help="A criteria when judging single copy exon", default=float(0.5))
    parser.add_argument("--MinIngroup", "-I", help="The min number of ingroup species that the MSA requires", default=int(2))
    parser.add_argument("--MinOutgroup", "-O", help="The min number of outgroup species that the MSA requires", default=int(1))
    parser.add_argument("--SelectScale", "-A", help="A criteria used in removing the rogue seqs, larger and more strict", default=float(1.1))
    parser.add_argument("--PIRatio", "-R", help="The scale between PCR score and infomation score when calculating the total score of primer pairs", default=int(1))
    parser.add_argument("--MinPCRLen", help="Min Length of the target peptide when PCR", default=int(100))
    parser.add_argument("--MaxPCRLen", help="Min Length of the target peptide when PCR", default=int(700))
    parser.add_argument("--MinIn2AAIdtt", help="A criteria used in searching for the possible primers", default=float(1))
    parser.add_argument("--MinOut2AAIdtt", help="A criteria used in searching for the possible primers", default=float(0.75))
    parser.add_argument("--MinInIdtt", help="A criteria used in searching for the possible primers", default=float(0.85))
    parser.add_argument("--MinAllIdtt", help="A criteria used in searching for the possible primers", default=float(0.75))
    parser.add_argument("--MaxGapRate", help="A criteria used in searching for the possible primers", default=float(0.3))
    parser.add_argument("--NestedPrimerDstc", help="The distance(petide) between F1 and F2, or between R1 and R2 of nested primer pairs", default=int(150))

    args = parser.parse_args()
    pipeline(args.MinExonLen,args.threads,args.cover,args.similarity,args.list,args.MinIngroup,args.MinOutgroup,args.PIRatio,
             args.MinPCRLen,args.MaxPCRLen,args.MinIn2AAIdtt,args.MinOut2AAIdtt,args.MinInIdtt,args.MinAllIdtt,args.MaxGapRate,
             args.NestedPrimerDstc,args.SelectScale,args.OutDir)

