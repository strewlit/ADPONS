import os
import glob
import log_and_summary_msa_6 as log
import argparse

class Mega:
    def __init__(self,fasta_path,mao_path,meg_path,out_dir):
        self.input_path = fasta_path
        self.output_path = meg_path
        self.mao_path = mao_path
        self.out_dir = out_dir
        if not os.path.exists(os.path.dirname(self.output_path)):
            os.mkdir(os.path.dirname(self.output_path))

    def make_align(self):
        log_in = 'Megacc satrts aligning: ' + self.output_path
        log.write_log(log_in,self.out_dir)
        if not os.path.exists(self.output_path):
            command = "megacc -f Fasta -a " + str(self.mao_path) + " -d " + str(self.input_path) + " -o " + str(self.output_path)
            print(command)
            os.system(command)


def pipeline(mao_path,fold_path,out_dir):

    pep_path_list = glob.glob(os.path.join(fold_path,'*.fasta'))
    #print(pep_path_list)
    for pep_path in pep_path_list:
        output_path = os.path.join(out_dir,'aligned_'+os.path.split(fold_path)[1],os.path.split(pep_path)[1])
        if not os.path.exists(os.path.dirname(output_path)):
            os.mkdir(os.path.dirname(output_path))
        if not os.path.exists(output_path):
            align_pep = Mega(pep_path,mao_path,output_path,out_dir)
            align_pep.make_align()

work_dir = r'E:\PycharmCode\test\taxa1'
mao_path = os.path.join(work_dir,'muscle_align_protein.mao')
fold_path = r'E:\PycharmCode\test\taxa1_result\target_peptide'
out_dir = r'E:\PycharmCode\test\taxa1_result'
#pipeline(work_dir,fold_path,out_dir)
#输入工作路径和需要align的文件夹

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="python UPrimer_V2.py --list -L")
    parser.add_argument("--InDir", "-I", help="The path of the folder whose fasta file you want to align", required=True)
    parser.add_argument("--OutDir", "-D", help="Your output directory", required=True)
    parser.add_argument("--MaoPath", "-M", help="Your mao file's path", required=True)

    args = parser.parse_args()
    pipeline(args.MaoPath,args.InDir,args.OutDir)
    #the aligned result will be saved in out_dir/aligned_---

