import numpy as np
from Bio import SeqIO
import os
import numpy
import glob
import pandas as pd
import log_and_summary_msa_6 as log
import argparse

#根据比对好的fasta矩阵输出一个字典，字典的键有两类，一类是‘ingroup_common_seq'和'total_common_seq'，对应值是一致性氨基酸序列且最后一位为了补齐长度所以填充为-，和'ingroup_identity'、'outgroup_identity'、’total_identity‘对应值是各位点相似性，最后一位是整体相似性，和'total_gap_rate'对应各位点的gap率，最后一位是平均gap率
# 另一类是align的所有物种名，对应值是各位点与一致性氨基酸是否相同的列表，相同为1，不同为0，最后一位是整体相似度。
def return_identity_info_dict(input_fasta_path):    #输入仅为fasta矩阵的绝对路径
    records = list(SeqIO.parse(open(input_fasta_path), 'fasta'))
    fasta_dict = SeqIO.to_dict(records,key_function=lambda i:i.description)
    key_list = list(fasta_dict.keys())
    align_info_dict = dict()    #键添加的顺序是物种、整体相似度、一致性氨基酸序列
    for key in key_list:
        align_info_dict[key] = []
    align_info_dict['total_gap_rate'] = []
    align_info_dict['ingroup_identity'] = []
    align_info_dict['outgroup_identity'] = []
    align_info_dict['total_identity'] = []
    align_info_dict['ingroup_common_seq'] = []      #两个一致性氨基酸序列
    align_info_dict['total_common_seq'] = []
    for site in range(0, len(next(SeqIO.parse(open(input_fasta_path), 'fasta')).seq)):      #横向遍历矩阵
        site_list = []
        ingroup_site_list = []
        for key in key_list:
            site_list.append(fasta_dict[key].seq[site])
            if not 'cds' in key:
                ingroup_site_list.append(fasta_dict[key].seq[site])
        max_site = max(site_list,key=site_list.count)
        max_ingroup_site = max(ingroup_site_list,key=ingroup_site_list.count)
        gap_rate = site_list.count('-')/len(key_list)
        align_info_dict['ingroup_common_seq'].append(max_ingroup_site)
        align_info_dict['total_common_seq'].append(max_site)
        #计算相似度,均是和内类群一致性氨基酸比较
        total_score = 0
        ingroup_score = 0
        ingoup_len = 0
        outgroup_score = 0
        outgroup_len = 0
        for key in key_list:
            if fasta_dict[key].seq[site] == max_ingroup_site:
                if 'cds' in key:
                    outgroup_len += 1
                    outgroup_score += 1
                else:
                    ingoup_len +=1
                    ingroup_score += 1
            else:
                if 'cds' in key:
                    outgroup_len += 1
                else:
                    ingoup_len +=1
        for key in key_list:
            if fasta_dict[key].seq[site] == max_site:
                align_info_dict[key].append(1)
                total_score +=1
            else:
                align_info_dict[key].append(0)
        average_score = total_score/len(key_list)     #该位点的整体相似度
        align_info_dict['total_identity'].append(average_score)
        average_score_ingroup = ingroup_score/ingoup_len
        align_info_dict['ingroup_identity'].append(average_score_ingroup)
        average_score_outgroup = outgroup_score/outgroup_len
        align_info_dict['outgroup_identity'].append(average_score_outgroup)
        align_info_dict['total_gap_rate'].append(gap_rate)
    for key in list(align_info_dict.keys())[0:-2]:      #计算每个序列的各位点相似度与整条平均相似度
        identity = (numpy.mean(align_info_dict[key]))
        align_info_dict[key].append(identity)
    for key in list(align_info_dict.keys())[-2:]:
        align_info_dict[key].append('-')
    #把ingroup、outgroup、total indentity和gap rate 信息写在csv里
    out_path = os.path.join(os.path.split(input_fasta_path)[0],os.path.split(input_fasta_path)[1].replace('.fasta','_info1.csv'))
    if not os.path.exists(out_path):
        df_out = pd.DataFrame([align_info_dict['ingroup_identity'],align_info_dict['outgroup_identity'],align_info_dict['total_identity'],align_info_dict['total_gap_rate'],align_info_dict['ingroup_common_seq'],align_info_dict['total_common_seq']],index=['ingroup_identity','outgoup_identity','total_identity','gap_rate','ingroup_common_seq','total_common_seq']).transpose()
        df_out.to_csv(out_path)
    return align_info_dict

#输入一个字符串序列，用下辛普森指数衡量序列破碎度，返回该序列的辛普森指数和gap含量
def calculate_Simpsonindex_and_GapPercentage(seq):
    length = 1
    length_list = list()
    converted_seq = ''      #该步我们只在意位点是不是gap而不在意具体是什么，所以转换为01序列，0是gap
    for i in range(0,len(seq)):
        if seq[i]=='-':
            converted_seq = converted_seq + '0'
        else:
            converted_seq = converted_seq + '1'
    gap_percentage = converted_seq.count('0')/len(seq)      #计算gap含量
    for i in range(0,len(seq)-1):       #判断连续性
        if converted_seq[i] == converted_seq[i+1]:
            length += 1
        else:
            length_list.append(length)
            length = 1
    length_list.append(length)
    Simpsonindex_score = 0
    for block_len in length_list:
        Simpsonindex_score = Simpsonindex_score + (block_len**2)/len(seq)**2        #计算辛普森指数
    return Simpsonindex_score,gap_percentage

#输入物种列表和最小类群数量，合格返回True，不合格返回False。注意，为了保证参考物种不变成光杆司令，内类群最小数量至少为2
def judge_group_number(remain_list,min_ingroup,min_outgroup):
    ingroup_count = 0
    outgroup_count = 0
    for specie in remain_list:
        if 'cds' in specie:
            outgroup_count += 1
        else:
            ingroup_count += 1
    if ingroup_count>=min_ingroup and outgroup_count>=min_outgroup:
        return True
    else:
        return False

#输入比对后的fasta文件，返回相似度、破碎度、gap率字典，键是物种名。
def return_identity_dict_and_Simpsonindex_list(input_fasta_path):
    identity_dict = return_identity_info_dict(input_fasta_path)     #键除了物种名，还有common_seq和total_identity，对应一致性氨基酸序列和位点上的整体相似度
    records = list(SeqIO.parse(open(input_fasta_path), 'fasta'))
    fasta_dict = SeqIO.to_dict(records, key_function=lambda i: i.description)
    Simpsonindex_dict = dict()
    GapPercentage_dict = dict()
    key_list = list(fasta_dict.keys())
    for key in key_list:
        seq = fasta_dict[key].seq
        Simpsonindex_dict[key] = calculate_Simpsonindex_and_GapPercentage(seq)[0]
        GapPercentage_dict[key] = calculate_Simpsonindex_and_GapPercentage(seq)[1]
    return identity_dict, Simpsonindex_dict, GapPercentage_dict

#输入需要去掉流氓序列的文件所在文件夹路径、程序工作路径、最小类群要求，结果是原地写入每个fasta的信息表，在target_peptide_without_rogue写入去掉rogue的fasta文件，并返回所含物种的字典
def pipeline(input_fold_path, out_dir, min_ingroup, min_outgroup, select_scale):
    pep_list = glob.glob(os.path.join(input_fold_path, '*.fasta'))
    #print(fasta_list)
    remove_all_count = 0
    remain_dict = dict()
    for pep_path in pep_list:
        log_in = 'Removing the rogues of ' + pep_path
        log.write_log(log_in,out_dir)
        print(os.path.split(pep_path)[1])
        pep_fasta_dict = SeqIO.to_dict(SeqIO.parse(open(pep_path), 'fasta'),key_function=lambda i:i.description)
        pep_output_fasta_path = os.path.join(out_dir, 'target_peptide_without_rogue', os.path.split(pep_path)[1])
        if not os.path.exists(os.path.dirname(pep_output_fasta_path)):
            os.mkdir(os.path.dirname(pep_output_fasta_path))

        if not os.path.exists(pep_output_fasta_path):
            pep_output_fasta_list = []
            cds_output_fasta_list = []
            fasta_info = return_identity_dict_and_Simpsonindex_list(pep_path)
            identity_dic = fasta_info[0]
            Simpsonindex_dic = fasta_info[1]
            GapPercentage_dic = fasta_info[2]
            species_list = list(Simpsonindex_dic.keys())
            remove_list = set()  # 流氓序列名称的列表
            #根据相似度筛选
            specie_identity_list = []       #不含参考物种，下同
            for specie in species_list[1:]:
                specie_identity_list.append(identity_dic[specie][-1])
            average_identity = np.mean(specie_identity_list)
            identity_std = np.std(specie_identity_list)
            for i in range(0,(len(species_list)-1)):        #移除不包括参考物种，下同
                if specie_identity_list[i]<average_identity-select_scale*identity_std:
                    remove_list.add(species_list[i+1])
            #根据gap含量筛选
            specie_gap_list = []
            for specie in species_list[1:]:
                specie_gap_list.append(GapPercentage_dic[specie])
            average_gap = np.mean(specie_gap_list)
            gap_std = np.std(specie_gap_list)
            for i in range(0,len(specie_gap_list)):
                if specie_gap_list[i]<average_gap-select_scale*gap_std or specie_gap_list[i]>average_gap+select_scale*gap_std:
                    remove_list.add(species_list[i+1])
            #根据破碎度筛选
            specie_Simpsonindex_list = []
            for specie in species_list[1:]:
                specie_gap_list.append(Simpsonindex_dic[specie])
            average_Simpsonindex = np.mean(specie_Simpsonindex_list)
            Simpsonindex_std = np.std(specie_Simpsonindex_list)
            for i in range(0,len(specie_Simpsonindex_list)):
                if specie_Simpsonindex_list[i]<average_Simpsonindex-select_scale*Simpsonindex_std:      #破碎越严重，辛普森指数越低
                    remove_list.add(species_list[i+1])

            print('该比对结果的整体相似性为', average_identity)
            print('该比对结果的整体相似性的标准差为 ', identity_std)
            print('移除',remove_list)
            print('移除：',len(remove_list),'\t','剩余：',len(specie_identity_list)-len(remove_list)+1,sep='\t')
            #生成保留的物种列表
            remain_list = species_list
            for specie in list(remove_list):
                remain_list.remove(specie)
            print('符合标准的物种有',remain_list)
            if len(remove_list)>(len(specie_identity_list)-3):
                print('这个fasta快删光了')
            remain_dict[os.path.split(pep_path)[1]] = remain_list
            all_species_count = len(species_list)
            remain_list_count = len(remain_list)
            log_in = 'Before: ' + repr(species_list)
            log.write_log(log_in,out_dir)
            log_in = 'After: ' + repr(remain_list)
            log.write_log(log_in,out_dir)
            #检查内外类群数量是否达标
            if judge_group_number(remain_list,min_ingroup,min_outgroup) and identity_dic[species_list[0]][-1]>=0.4:
                cds_path = pep_path.replace('aligned_target_peptide', 'aligned_target_cds')
                if os.path.exists(cds_path):
                    cds_fasta_dict = SeqIO.to_dict(SeqIO.parse(open(cds_path), 'fasta'),
                                                   key_function=lambda i: i.description.replace('<', '').replace('>',
                                                                                                                 '').replace(
                                                       ';', ' ').replace('_', ' '))
                    cds_output_fasta_path = os.path.join(out_dir, 'target_cds_without_rogue', os.path.split(pep_path)[1])
                    if not os.path.exists(os.path.dirname(cds_output_fasta_path)):
                        os.mkdir(os.path.dirname(cds_output_fasta_path))
                for record in remain_list:
                    pep_output_fasta_list.append(pep_fasta_dict[record])
                    if os.path.exists(cds_path):
                        cds_output_fasta_list.append(cds_fasta_dict[record])
                #print(output_fasta_path)
                #print(output_fasta_list)
                SeqIO.write(pep_output_fasta_list,pep_output_fasta_path,'fasta')
                if os.path.exists(cds_path):
                    SeqIO.write(cds_output_fasta_list,cds_output_fasta_path,'fasta')
            else:
                remain_dict.pop(os.path.split(pep_path)[1])
                print('该fasta不合格')
            print('\n')
        else:
            print('Fasta withou rogue is existed','\n')
    log_in = 'Completed quality control'
    log.write_log(log_in,out_dir)
    return remain_dict


'''test_dict = return_identity_info_dict(r'D:\PycharmCode\test\taxa1\aligned_peptide\55.fasta')
for key in list(test_dict.keys())[1:-1]:
    print(key)
    print(test_dict[key][-1])'''
#block_len_list = calculate_Simpsonindex_and_GapPercentage(r'shdf---kclkd---cjlas---joijc')
#print(block_len_list)
#fasta_info = return_identity_dict_and_Simpsonindex_list(r'D:\PycharmCode\test\taxa1\aligned_peptide\57.fasta')
#print(fasta_info[1])
#print(fasta_info[2])
#print(fasta_info[0].keys())
#print('common_seq',len(fasta_info[0]['common_seq']))
#print('ingroup_identity', fasta_info[0]['ingroup_identity'][-1])
#print('outgroup_identity', fasta_info[0]['outgroup_identity'][-1])
#print('total_identity', fasta_info[0]['total_identity'][-1])
#print('gap_rate',fasta_info[0]['total_gap_rate'][-1])
#print(len(fasta_info[0]['total_gap_rate']),len(fasta_info[0]['ingroup_identity']),len(fasta_info[0]['outgroup_identity']),len(fasta_info[0]['total_identity']))

#remain_dict = pipeline(r'E:\PycharmCode\test\taxa1_result\aligned_target_peptide', r'E:\PycharmCode\test\taxa1_result', 2, 1, 1.1)
#输入需要除流氓的文件夹路径、工作路径、最小内类群数量和最小外类群数量
#print(remain_dict)
#print(len(remain_dict.keys()))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="python UPrimer_V2.py --list -L")
    parser.add_argument("--InDir", "-L", help="The path of folder whose aligned fasta file you want to remove rogues and quality conrol", required=True)
    parser.add_argument("--OutDir", "-D", help="Your output directory", required=True)
    parser.add_argument("--MinIngroup", "-I", help="The min number of ingroup species that the MSA requires", default=int(2))
    parser.add_argument("--MinOutgroup", "-O", help="The min number of outgroup species that the MSA requires", default=int(1))
    parser.add_argument("--SelectScale", "-A", help="A criteria used in removing the rogue seqs, larger and more strict", default=float(1.1))

    args = parser.parse_args()
    pipeline(args.InDir,args.OutDir,args.MinIngroup,args.MinOutgroup,args.SelectScale)
