import os.path
import glob
import remove_rogue_and_quality_control_4 as rm7qc
import megacc_test_3 as mega
import numpy as np
from Bio.Seq import Seq
import pandas as pd
import log_and_summary_msa_6 as log
import argparse

AA2degen_dict = dict(zip('GAVIPFYWTCMNQDEKH-XLSR', [4, 4, 4, 3, 4, 2, 2, 1, 4, 2, 1, 2, 2, 2, 2, 2, 2, 0, 0, 8, 16, 8]))
AA2nucl_dict = dict(zip('GAVIPFYWTCMNQDEKH-XLSR', ['GGN', 'GCN', 'GTN', 'ATH', 'CCN', 'TTY', 'TAY', 'TGG', 'ACN', 'TGY',
                                                   'ATG', 'AAY', 'CAR', 'GAY', 'GAR', 'AAR', 'CAY', '---', 'XXX',
                                                   'YTN', 'WSN', 'MGN']))
nucl2degen_dict = dict(zip('-XATCGRYMKSWBVHDN', [0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 4]))

PCR_score_scale = [1, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3]
ingroup_scale = np.arange(0.4375, 1.0625, 0.0625)


def calculate_nucl_degen(seq):
    degen = 1
    for site in range(0, len(seq)):
        degen *= nucl2degen_dict[seq[site]]
    return degen


def pep2nucl(pep):
    nucl_seq = ''
    for site in range(0, len(pep)):
        nucl_seq = nucl_seq + AA2nucl_dict[pep[site]]
    return nucl_seq


class Primer_pair:
    def __init__(self, window1_start, window2_start, primer_length, common_seq, common_seq_identity):
        self.window1_start = window1_start
        self.window2_start = window2_start
        self.primer_length = primer_length
        self.forward_2AA = common_seq[window1_start + primer_length - 2:window1_start + primer_length]  # 列表
        self.reverse_2AA = common_seq[window2_start:window2_start + 2]  # 列表
        self.forward_primer_pep = ''.join(common_seq[window1_start:window1_start + primer_length])  # 字符串
        self.reverse_primer_pep = ''.join(common_seq[window2_start:window2_start + primer_length])  # 字符串
        self.forward_primer_nucl = pep2nucl(self.forward_primer_pep)[0:-1]
        self.reverse_primer_nucl = str(Seq(pep2nucl(self.reverse_primer_pep)).reverse_complement()[1:])
        self.pcr_pep = common_seq[window1_start:window2_start + primer_length]  # 列表
        self.pcr_identity = common_seq_identity[window1_start:window2_start + primer_length]  # 列表
        self.forward_degen = calculate_nucl_degen(self.forward_primer_nucl)
        self.reverse_degen = calculate_nucl_degen(self.reverse_primer_nucl)

    def calculate_PCRScore(self):
        self.score_PCR = 100
        # 先减去正向引物
        for site in range(0, len(self.forward_primer_pep)):
            self.score_PCR = self.score_PCR - AA2degen_dict[self.forward_primer_pep[site]] * PCR_score_scale[
                self.primer_length - site - 1]
        # 再减去反向引物
        for site in range(0, len(self.reverse_primer_pep)):
            self.score_PCR = self.score_PCR - AA2degen_dict[self.reverse_primer_pep[site]] * PCR_score_scale[site]
        return self.score_PCR

    def calculate_InfoScore(self, max_PCR_length):
        self.score_info = len(self.pcr_identity) - np.sum(self.pcr_identity)
        return self.score_info


def calculate_pep_degeneration(seq):
    degeneration = 1
    for site in seq:
        degeneration *= AA2degen_dict[site]
    return degeneration

def judege_3AA_successive(seq):
    length = len(seq)
    successive_count = 0
    for site in range(0,length-2):
        if seq[site] == seq[site+1] and seq[site] == seq[site+2]:
            successive_count += 1
    if successive_count == 0:
        return False
    else:
        return True


# 输入fasta相似度信息字典，由上一模块输出。还要输入五个常数：内类群2AA最低相似度，外类群2AA最低相似度，内类群引物最低相似度，外类群引物最低相似度，gap最大容忍率
def select_primer(fasta_info_dict, min_in_2AA_idtt, min_out_2AA_idtt, min_in_idtt, min_total_idtt, max_gap_rate,
                  max_2AA_degen, max_2AA_degen_loose, max_total_degen):
    forward_7AA_primer = dict()  # 以引物近端起点为键，以简并度为值，包含整条和2AA简并度
    reverse_7AA_primer = dict()
    forward_8AA_primer = dict()  # 以引物近端起点为键，以简并度为值，包含整条和2AA简并度
    reverse_8AA_primer = dict()
    forward_7AA_primer_loose = dict()  # 以引物近端起点为键，以简并度为值，包含整条和2AA简并度
    reverse_7AA_primer_loose = dict()
    forward_8AA_primer_loose = dict()  # 以引物近端起点为键，以简并度为值，包含整条和2AA简并度
    reverse_8AA_primer_loose = dict()
    fasta_length = len(fasta_info_dict['total_common_seq'])
    ingroup_identity = fasta_info_dict['ingroup_identity']
    outgroup_identity = fasta_info_dict['outgroup_identity']
    total_identity = fasta_info_dict['total_identity']
    total_gap_rate = fasta_info_dict['total_gap_rate']
    ingroup_common_seq = fasta_info_dict['ingroup_common_seq']
    # print(total_common_seq)
    # 筛选先判断相似度，后判断是否含LSR
    for site in range(0, fasta_length - 8, 1):
        # 筛选7AA
        window_ingroup_identity = ingroup_identity[site:site + 7]
        window_outgroup_identity = outgroup_identity[site:site + 7]
        window_total_identity = total_identity[site:site + 7]
        window_gap_rate = total_gap_rate[site:site + 7]
        window_common_seq = ''.join(ingroup_common_seq[site:site + 7])
        if '*' in window_common_seq:
            print(ingroup_common_seq)
            #window_common_seq = window_common_seq.replace('*','')
            continue
        if judege_3AA_successive(window_common_seq):
            continue
        abandon_AA = ['L', 'S', 'R', 'W', 'M']
        forward_abandon_AA_count_dict = {'L': 0, 'S': 0, 'R': 0, 'W': 0, 'M': 0}
        reverse_abandon_AA_count_dict = {'L': 0, 'S': 0, 'R': 0, 'W': 0, 'M': 0}
        for AA in abandon_AA:
            forward_abandon_AA_count_dict[AA] = window_common_seq[-2:].count(AA)
            reverse_abandon_AA_count_dict[AA] = window_common_seq[0:2].count(AA)

        # 筛选7AA正向
        if np.mean(window_ingroup_identity[-2:]) == min_in_2AA_idtt and np.mean(
                window_outgroup_identity[-2:]) >= min_out_2AA_idtt and np.mean(
            window_ingroup_identity) >= min_in_idtt and np.mean(
            window_total_identity) >= min_total_idtt and np.mean(
            window_gap_rate) <= max_gap_rate:
            # 内部引物标准
            if forward_abandon_AA_count_dict['L'] + forward_abandon_AA_count_dict['S'] + forward_abandon_AA_count_dict[
                'R'] == 0 and forward_abandon_AA_count_dict['W'] + forward_abandon_AA_count_dict[
                'M'] <= 1 and '-' not in window_common_seq:
                if calculate_pep_degeneration(window_common_seq) <= max_total_degen and calculate_pep_degeneration(
                        window_common_seq[-2:]) <= max_2AA_degen:
                    # print(window_common_seq)
                    # print(site)
                    forward_7AA_primer[site] = [calculate_pep_degeneration(window_common_seq) / nucl2degen_dict[
                        AA2nucl_dict[window_common_seq[-1]][-1]],
                                                calculate_pep_degeneration(window_common_seq[-2:]) /
                                                nucl2degen_dict[AA2nucl_dict[window_common_seq[-1]][-1]],
                                                window_common_seq]
            # 外部引物标准
            if forward_abandon_AA_count_dict['L'] + forward_abandon_AA_count_dict['S'] + forward_abandon_AA_count_dict[
                'R'] + forward_abandon_AA_count_dict['W'] + forward_abandon_AA_count_dict[
                'M'] <= 1 and '-' not in window_common_seq and window_common_seq[-1] not in ['L', 'S', 'R']:
                if calculate_pep_degeneration(window_common_seq) <= max_total_degen * 4 and calculate_pep_degeneration(
                        window_common_seq[-2:]) <= max_2AA_degen_loose:
                    # print(window_common_seq)
                    # print(site)
                    forward_7AA_primer_loose[site] = [calculate_pep_degeneration(window_common_seq) / nucl2degen_dict[
                        AA2nucl_dict[window_common_seq[-1]][-1]],
                                                      calculate_pep_degeneration(window_common_seq[-2:]) /
                                                      nucl2degen_dict[AA2nucl_dict[window_common_seq[-1]][-1]],
                                                      window_common_seq]
        # 筛选7AA反向
        if np.mean(window_ingroup_identity[0:2]) == min_in_2AA_idtt and np.mean(
                window_outgroup_identity[0:2]) >= min_out_2AA_idtt and np.mean(
            window_ingroup_identity) >= min_in_idtt and np.mean(
            window_total_identity) >= min_total_idtt and np.mean(
            window_gap_rate) <= max_gap_rate:
            # 内部引物标准
            if reverse_abandon_AA_count_dict['L'] + reverse_abandon_AA_count_dict['S'] + reverse_abandon_AA_count_dict[
                'R'] == 0 and reverse_abandon_AA_count_dict['W'] + reverse_abandon_AA_count_dict[
                'M'] <= 1 and '-' not in window_common_seq:
                if calculate_pep_degeneration(window_common_seq) <= max_total_degen and calculate_pep_degeneration(
                        window_common_seq[0:2]) <= max_2AA_degen:
                    # print(window_common_seq)
                    # print(site)
                    reverse_7AA_primer[site] = [calculate_pep_degeneration(window_common_seq) / nucl2degen_dict[
                        AA2nucl_dict[window_common_seq[-1]][-1]],
                                                calculate_pep_degeneration(window_common_seq[0:2]), window_common_seq]
            # 外部引物标准
            if reverse_abandon_AA_count_dict['L'] + reverse_abandon_AA_count_dict['S'] + reverse_abandon_AA_count_dict[
                'R'] + reverse_abandon_AA_count_dict['W'] + reverse_abandon_AA_count_dict[
                'M'] <= 1 and '-' not in window_common_seq and window_common_seq[0] not in ['L', 'S', 'R']:
                if calculate_pep_degeneration(window_common_seq) <= max_total_degen * 4 and calculate_pep_degeneration(
                        window_common_seq[0:2]) <= max_2AA_degen_loose:
                    # print(window_common_seq)
                    # print(site)
                    reverse_7AA_primer_loose[site] = [calculate_pep_degeneration(window_common_seq) / nucl2degen_dict[
                        AA2nucl_dict[window_common_seq[-1]][-1]],
                                                      calculate_pep_degeneration(window_common_seq[0:2]),
                                                      window_common_seq]
        # 筛选8AA
        window_ingroup_identity = ingroup_identity[site:site + 8]
        window_outgroup_identity = outgroup_identity[site:site + 8]
        window_total_identity = total_identity[site:site + 8]
        window_gap_rate = total_gap_rate[site:site + 8]
        window_common_seq = ''.join(ingroup_common_seq[site:site + 8])
        if '*' in window_common_seq:
            print(ingroup_common_seq)
            #window_common_seq = window_common_seq.replace('*','')
            continue
        abandon_AA = ['L', 'S', 'R', 'W', 'M']
        forward_abandon_AA_count_dict = {'L': 0, 'S': 0, 'R': 0, 'W': 0, 'M': 0}
        reverse_abandon_AA_count_dict = {'L': 0, 'S': 0, 'R': 0, 'W': 0, 'M': 0}
        for AA in abandon_AA:
            forward_abandon_AA_count_dict[AA] = window_common_seq[-2:].count(AA)
            reverse_abandon_AA_count_dict[AA] = window_common_seq[0:2].count(AA)

        # 筛选8AA正向
        if np.mean(window_ingroup_identity[-2:]) == min_in_2AA_idtt and np.mean(
                window_outgroup_identity[-2:]) >= min_out_2AA_idtt and np.mean(
            window_ingroup_identity) >= min_in_idtt and np.mean(
            window_total_identity) >= min_total_idtt and np.mean(
            window_gap_rate) <= max_gap_rate:
            # 内部引物标准
            if forward_abandon_AA_count_dict['L'] + forward_abandon_AA_count_dict['S'] + forward_abandon_AA_count_dict[
                'R'] == 0 and forward_abandon_AA_count_dict['W'] + forward_abandon_AA_count_dict[
                'M'] <= 1 and '-' not in window_common_seq:
                if calculate_pep_degeneration(window_common_seq) <= max_total_degen and calculate_pep_degeneration(
                        window_common_seq[-2:]) <= max_2AA_degen:
                    # print(window_common_seq)
                    # print(site)
                    forward_8AA_primer[site] = [calculate_pep_degeneration(window_common_seq) / nucl2degen_dict[
                        AA2nucl_dict[window_common_seq[-1]][-1]],
                                                calculate_pep_degeneration(window_common_seq[-2:]) /
                                                nucl2degen_dict[AA2nucl_dict[window_common_seq[-1]][-1]],
                                                window_common_seq]
            # 外部引物标准
            if forward_abandon_AA_count_dict['L'] + forward_abandon_AA_count_dict['S'] + forward_abandon_AA_count_dict[
                'R'] + forward_abandon_AA_count_dict['W'] + forward_abandon_AA_count_dict[
                'M'] <= 1 and '-' not in window_common_seq and window_common_seq[-1] not in ['L', 'S', 'R']:
                if calculate_pep_degeneration(window_common_seq) <= max_total_degen * 4 and calculate_pep_degeneration(
                        window_common_seq[-2:]) <= max_2AA_degen_loose:
                    # print(window_common_seq)
                    # print(site)
                    forward_8AA_primer_loose[site] = [calculate_pep_degeneration(window_common_seq) / nucl2degen_dict[
                        AA2nucl_dict[window_common_seq[-1]][-1]],
                                                      calculate_pep_degeneration(window_common_seq[-2:]) /
                                                      nucl2degen_dict[AA2nucl_dict[window_common_seq[-1]][-1]],
                                                      window_common_seq]
        # 筛选8AA反向
        if np.mean(window_ingroup_identity[0:2]) == min_in_2AA_idtt and np.mean(
                window_outgroup_identity[0:2]) >= min_out_2AA_idtt and np.mean(
            window_ingroup_identity) >= min_in_idtt and np.mean(
            window_total_identity) >= min_total_idtt and np.mean(
            window_gap_rate) <= max_gap_rate:
            # 内部引物标准
            if reverse_abandon_AA_count_dict['L'] + reverse_abandon_AA_count_dict['S'] + reverse_abandon_AA_count_dict[
                'R'] == 0 and reverse_abandon_AA_count_dict['W'] + reverse_abandon_AA_count_dict[
                'M'] <= 1 and '-' not in window_common_seq:
                if calculate_pep_degeneration(window_common_seq) <= max_total_degen and calculate_pep_degeneration(
                        window_common_seq[0:2]) <= max_2AA_degen:
                    # print(window_common_seq)
                    # print(site)
                    reverse_8AA_primer[site] = [calculate_pep_degeneration(window_common_seq) / nucl2degen_dict[
                        AA2nucl_dict[window_common_seq[-1]][-1]],
                                                calculate_pep_degeneration(window_common_seq[0:2]), window_common_seq]
            # 外部引物标准
            if reverse_abandon_AA_count_dict['L'] + reverse_abandon_AA_count_dict['S'] + reverse_abandon_AA_count_dict[
                'R'] + reverse_abandon_AA_count_dict['W'] + reverse_abandon_AA_count_dict[
                'M'] <= 1 and '-' not in window_common_seq and window_common_seq[0] not in ['L', 'S', 'R']:
                if calculate_pep_degeneration(window_common_seq) <= max_total_degen * 4 and calculate_pep_degeneration(
                        window_common_seq[0:2]) <= max_2AA_degen_loose:
                    # print(window_common_seq)
                    # print(site)
                    reverse_8AA_primer_loose[site] = [calculate_pep_degeneration(window_common_seq) / nucl2degen_dict[
                        AA2nucl_dict[window_common_seq[-1]][-1]],
                                                      calculate_pep_degeneration(window_common_seq[0:2]),
                                                      window_common_seq]

    return forward_7AA_primer, reverse_7AA_primer, forward_8AA_primer, reverse_8AA_primer, forward_7AA_primer_loose, reverse_7AA_primer_loose, forward_8AA_primer_loose, reverse_8AA_primer_loose


def return_ingroup_scale(ingroup_count):
    if ingroup_count <= 10:
        return ingroup_scale[ingroup_count - 1]
    else:
        return float(1)


def find_nest_primer(in_primer_pair_dict, out_primer_pair_dict, in_primer_pair_length, out_primer_pair_length,
                     search_distance, PI_ratio):
    in_candidate = list(in_primer_pair_dict.keys())
    in_candidate.sort(reverse=True)
    out_candidate = list(out_primer_pair_dict.keys())
    out_candidate.sort(reverse=True)
    is_best = 0
    best_nest_info = []
    for in_pair in in_candidate:
        for out_pair in out_candidate:
            in_forward = in_primer_pair_dict[in_pair][0]
            in_reverse = in_primer_pair_dict[in_pair][1]
            out_forward = out_primer_pair_dict[out_pair][0]
            out_reverse = out_primer_pair_dict[out_pair][1]
            if in_forward - out_forward >= out_primer_pair_length and in_forward - out_forward <= search_distance and out_reverse - in_reverse >= in_primer_pair_length and out_reverse - in_reverse <= search_distance:
                best_nest_info = out_primer_pair_dict[out_pair] + in_primer_pair_dict[in_pair]
                best_nest_info.append(
                    in_primer_pair_dict[in_pair][7] + return_ingroup_scale(in_primer_pair_dict[in_pair][12]) *
                    out_primer_pair_dict[out_pair][5] * (PI_ratio / (1 + PI_ratio)))
                is_best = 1
            if is_best == 1:
                break
        if is_best == 1:
            break
    return best_nest_info


def find_standard_primer(forward_dict, reverse_dict, primer_length, min_PCR_length, max_PCR_length, common_seq,
                         common_seq_identity, PI_ratio, ingroup_count, loose_or_not, max_total_degen):
    primer_pair_dict = {}
    if forward_dict != {} and reverse_dict != {}:
        # 遍历所有引物组合
        for forward_site in list(forward_dict.keys()):
            for reverse_site in list(reverse_dict.keys()):
                if reverse_site - primer_length - forward_site >= min_PCR_length and reverse_site - primer_length - forward_site <= max_PCR_length:  # 长度不达标先筛选掉
                    PCR_length = (reverse_site + primer_length - forward_site) * 3
                    test_class = Primer_pair(forward_site, reverse_site, primer_length, common_seq, common_seq_identity)
                    PCRscore = test_class.calculate_PCRScore()
                    InfoScore = test_class.calculate_InfoScore(max_PCR_length)
                    total_score = (PI_ratio * PCRscore + InfoScore) / (1 + PI_ratio) * return_ingroup_scale(
                        ingroup_count)
                    # print(test_class.forward_primer_pep, test_class.forward_2AA)
                    # print(test_class.reverse_primer_pep, test_class.reverse_2AA)
                    # print('PCR分数', PCRscore)
                    # print('info分数', InfoScore)
                    # print('总分数', total_score)
                    # 该片段的引物集将设置为字典，键是总分（有隐患但不大），值是列表【forward起点，reverse起点，f_degen,r_degen,长度，PCR分数，Info分数，总分，f_pep,r_pep,f_nucl,r_nucl,ingroup】
                    if '-' not in test_class.forward_primer_pep and '-' not in test_class.reverse_primer_pep:
                        if loose_or_not == 0:
                            if test_class.forward_degen<=max_total_degen and test_class.reverse_degen<=max_total_degen:
                                while PCRscore in primer_pair_dict.keys():
                                    PCRscore = PCRscore * 1.0001
                                primer_pair_dict[PCRscore] = [forward_site, reverse_site, test_class.forward_degen,
                                                                 test_class.reverse_degen, PCR_length, PCRscore, InfoScore,
                                                                 total_score, test_class.forward_primer_pep,
                                                                 test_class.reverse_primer_pep,
                                                                 test_class.forward_primer_nucl,
                                                                 test_class.reverse_primer_nucl, ingroup_count]
                        else:
                            if test_class.forward_degen<=max_total_degen and test_class.reverse_degen<=max_total_degen:
                                while PCRscore in primer_pair_dict.keys():
                                    PCRscore = PCRscore * 1.0001
                                primer_pair_dict[PCRscore] = [forward_site, reverse_site, test_class.forward_degen,
                                                              test_class.reverse_degen, PCR_length, PCRscore, InfoScore,
                                                              total_score, test_class.forward_primer_pep,
                                                              test_class.reverse_primer_pep,
                                                              test_class.forward_primer_nucl,
                                                              test_class.reverse_primer_nucl, ingroup_count]
    return primer_pair_dict


def pipeline(work_dir, fold_path, PI_ratio, min_PCR_length, max_PCR_length, min_in_2AA_idtt, min_out_2AA_idtt,
             min_in_idtt, min_total_idtt, max_gap_rate, search_distance, out_dir):
    pep_mao_path = os.path.join(work_dir, 'muscle_align_protein.mao')
    cds_mao_path = os.path.join(work_dir, 'muscle_align_nucleotide.mao')
    cds_fold_path = fold_path.replace('target_peptide', 'target_cds')
    mega.pipeline(pep_mao_path, fold_path, out_dir)
    if os.path.exists(cds_fold_path):
        mega.pipeline(cds_mao_path, cds_fold_path, out_dir)
    NoRogue_aligned_fasta_fold_path = os.path.join(out_dir, 'aligned_target_peptide_without_rogue')
    NoRogue_aligned_fasta_path_list = glob.glob(os.path.join(NoRogue_aligned_fasta_fold_path, '*.fasta'))
    primer_7AA_standard_dict = {}  # 以外显子名称为键，列表为值，【forward起点，reverse起点，PCR分数，Info分数，总分，f_pep,r_pep,f_nucl,r_nucl,ingroup数量】
    primer_8AA_standard_dict = {}
    primer_78AA_nest_dict = {}
    primer_77AA_nest_dict = {}
    for fasta_path in NoRogue_aligned_fasta_path_list:
        print(fasta_path, '\n')
        # 有用的键有['total_gap_rate', 'ingroup_identity', 'outgroup_identity', 'total_identity', 'ingroup_common_seq', 'total_common_seq']
        fasta_info_dict = rm7qc.return_identity_info_dict(fasta_path)
        # print(list(fasta_info_dict.keys())[-6:])
        if fasta_info_dict['total_identity'][-1]<=0.9:
            log_in = 'Designing primers for ' + fasta_path
            log.write_log(log_in,out_dir)
            fasta_length = len(fasta_info_dict['total_common_seq'])
            species_list = list(fasta_info_dict.keys())[0:-6]
            ingroup_count = 0
            for specie in species_list:
                if not 'cds' in specie:
                    ingroup_count += 1
            common_seq = fasta_info_dict['ingroup_common_seq']
            common_seq_identity = fasta_info_dict['ingroup_identity']
            # 筛选合适的读码框
            # 列表返回forward_7AA_primer, reverse_7AA_primer, forward_8AA_primer, reverse_8AA_primer
            primer_info_dict = select_primer(fasta_info_dict, min_in_2AA_idtt, min_out_2AA_idtt, min_in_idtt,
                                             min_total_idtt,
                                             max_gap_rate, 8, 32, 32768)

            # 开始处理7AA标准引物对
            primer_pair_7AA_dict = find_standard_primer(primer_info_dict[0], primer_info_dict[1], 7, min_PCR_length,
                                                        max_PCR_length, common_seq, common_seq_identity, PI_ratio,
                                                        ingroup_count, 0, 8192)
            log_in = 'In ' + fasta_path + ', ' + str(len(
                primer_pair_7AA_dict)) + 'pairs of 7AA standard primer pairs are found'
            log.write_log(log_in, out_dir)

            # 开始处理8AA标准引物对
            primer_pair_8AA_dict = find_standard_primer(primer_info_dict[2], primer_info_dict[3], 8, min_PCR_length,
                                                        max_PCR_length, common_seq, common_seq_identity, PI_ratio,
                                                        ingroup_count, 0, 8192)
            log_in = 'In '+fasta_path+', '+str(len(primer_pair_8AA_dict))+'pairs of 8AA standard primer pairs are found'
            log.write_log(log_in,out_dir)

            # 生成一组外部引物标准的7AA标准引物对
            primer_pair_7AA_dict_loose = find_standard_primer(primer_info_dict[4], primer_info_dict[5], 7, min_PCR_length,
                                                              max_PCR_length, common_seq, common_seq_identity, PI_ratio,
                                                              ingroup_count, 1, 8192)

            # 根据primer_pair字典寻找巢式引物
            nest_77_info = []
            nest_78_info = []
            if primer_pair_7AA_dict_loose != {} and primer_pair_8AA_dict != {}:
                nest_78_info = find_nest_primer(primer_pair_8AA_dict, primer_pair_7AA_dict_loose, 8, 7, search_distance,
                                                PI_ratio)
            if nest_78_info != []:
                primer_78AA_nest_dict[species_list[0].replace('unknown id ', '')] = nest_78_info
            if primer_pair_7AA_dict_loose != {} and primer_pair_7AA_dict != {}:
                nest_77_info = find_nest_primer(primer_pair_7AA_dict, primer_pair_7AA_dict_loose, 7, 7, search_distance,
                                                PI_ratio)
            if nest_77_info != []:
                primer_77AA_nest_dict[species_list[0].replace('unknown id ', '')] = nest_77_info

            # 输出标准引物
            if primer_pair_7AA_dict != {}:
                best_7AA_info = primer_pair_7AA_dict[max(primer_pair_7AA_dict.keys())]
                primer_7AA_standard_dict[species_list[0].replace('unknown id ', '')] = best_7AA_info
            if primer_pair_8AA_dict != {}:
                best_8AA_info = primer_pair_8AA_dict[max(primer_pair_8AA_dict.keys())]
                primer_8AA_standard_dict[species_list[0].replace('unknown id ', '')] = best_8AA_info



    # 写入
    index_standard = ['f_pep_start', 'r_pep_start', 'f_degeneracy', 'r_degeneracy', 'length', 'PCR score',
                      'infomation score', 'total score', 'f_pep', 'r_pep', 'f_nucl', 'r_nucl', 'ingroup']
    df_7AA = pd.DataFrame(primer_7AA_standard_dict, index=index_standard).transpose().sort_values(by='total score',
                                                                                                  ascending=False)
    df_7AA.to_csv(os.path.join(out_dir, 'Standard_Primer_7AA_FR_' + str(df_7AA.shape[0]) + '.csv'))
    df_7AA_simplify = df_7AA[
        ['length', 'f_degeneracy', 'r_degeneracy', 'ingroup', 'f_nucl', 'r_nucl']]
    df_7AA_simplify.to_csv(
        os.path.join(out_dir, 'Standard_Primer_7AA_FR_' + str(df_7AA.shape[0]) + '_for_synthesis' + '.csv'))

    df_8AA = pd.DataFrame(primer_8AA_standard_dict, index=index_standard).transpose().sort_values(by='total score',
                                                                                                  ascending=False)
    df_8AA.to_csv(os.path.join(out_dir, 'Standard_Primer_8AA_FR_' + str(df_8AA.shape[0]) + '.csv'))
    df_8AA_simplify = df_8AA[
        ['length', 'f_degeneracy', 'r_degeneracy', 'ingroup', 'f_nucl', 'r_nucl']]
    df_8AA_simplify.to_csv(
        os.path.join(out_dir, 'Standard_Primer_8AA_FR_' + str(df_8AA.shape[0]) + '_for_synthesis' + '.csv'))

    index_nest = ['f1_pep_start', 'r1_pep_start', 'f1_degeneracy', 'r1_degeneracy', '1_length', '1_PCR score',
                  '1_infomation score', '1_total score', 'f1_pep', 'r1_pep', 'f1_nucl', 'r1_nucl', 'ingroup',
                  'f2_pep_start', 'r2_pep_start', 'f2_degeneracy', 'r2_degeneracy', '2_length', '2_PCR score',
                  '2_infomation score', '2_total score', 'f2_pep', 'r2_pep', 'f2_nucl', 'r2_nucl', 'ingroup',
                  'nest_primer_score']

    df_78AA = pd.DataFrame(primer_78AA_nest_dict, index=index_nest).transpose().sort_values(by='nest_primer_score',
                                                                                            ascending=False)
    df_78AA.to_csv(os.path.join(out_dir, 'Nested_Primer_8AA_F2R2_7AA_F1R1_' + str(df_78AA.shape[0]) + '.csv'))
    df_78AA_simplify = df_78AA[
        ['2_length', 'f2_degeneracy', 'r2_degeneracy', 'ingroup', 'f1_nucl', 'r1_nucl', 'f2_nucl', 'r2_nucl']]
    df_78AA_simplify.to_csv(
        os.path.join(out_dir, 'Nested_Primer_8AA_F2R2_7AA_F1R1_' + str(df_78AA.shape[0]) + '_for_synthesis' + '.csv'))

    df_77AA = pd.DataFrame(primer_77AA_nest_dict, index=index_nest).transpose().sort_values(by='nest_primer_score',
                                                                                            ascending=False)
    df_77AA.to_csv(os.path.join(out_dir, 'Nested_Primer_7AA_F2R2_7AA_F1R1_' + str(df_77AA.shape[0]) + '.csv'))
    df_77AA_simplify = df_77AA[
        ['2_length', 'f2_degeneracy', 'r2_degeneracy', 'ingroup', 'f1_nucl', 'r1_nucl', 'f2_nucl', 'r2_nucl']]
    df_77AA_simplify.to_csv(
        os.path.join(out_dir, 'Nested_Primer_7AA_F2R2_7AA_F1R1_' + str(df_77AA.shape[0]) + '_for_synthesis' + '.csv'))

    log_in = 'The result of designed primer pairs is saved in ' + out_dir
    log.write_log(log_in,out_dir)

#work_dir = r'E:\PycharmCode\test\taxa1'
#fold_path = r'E:\PycharmCode\test\taxa1_result\target_peptide_without_rogue'
#out_dir = r'E:\PycharmCode\test\taxa1_result'
# pipeline(work_dir, fold_path, 1, 100, 700, 1, 0.9, 0.85, 0.75, 0.3, 150,out_dir)
# 输入工作路径、没流氓的对齐矩阵文件夹、PCR与Info分数比例、信号区最小长度、信号区最大长度、内类群2AA最低相似度，外类群2AA最低相似度，内类群引物最低相似度，整体引物最低相似度，gap最大容忍率、巢式外围引物搜索范围

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="python UPrimer_V2.py --list -L")
    parser.add_argument("--WorkDir", "-W", help="Your database path", required=True)
    parser.add_argument("--InDir", "-D", help="The path of folder whose fasta file you want to search for primer pairs", required=True)
    parser.add_argument("--OutDir", "-D", help="Your output directory", required=True)
    parser.add_argument("--PIRatio", "-R", help="The scale between PCR score and infomation score when calculating the total score of primer pairs", default=int(3))
    parser.add_argument("--MinPCRLen", help="Min Length of the target peptide when PCR", default=int(100))
    parser.add_argument("--MaxPCRLen", help="Min Length of the target peptide when PCR", default=int(700))
    parser.add_argument("--MinIn2AAIdtt", help="A criteria used in searching for the possible primers", default=float(1))
    parser.add_argument("--MinOut2AAIdtt", help="A criteria used in searching for the possible primers", default=float(0.9))
    parser.add_argument("--MinInIdtt", help="A criteria used in searching for the possible primers", default=float(0.85))
    parser.add_argument("--MinAllIdtt", help="A criteria used in searching for the possible primers", default=float(0.75))
    parser.add_argument("--MaxGapRate", help="A criteria used in searching for the possible primers", default=float(0.3))
    parser.add_argument("--NestedPrimerDstc", help="The distance(petide) between F1 and F2, or between R1 and R2 of nested primer pairs", default=int(150))

    args = parser.parse_args()
    pipeline(args.WorkDir,args.Indir,args.PIRatio,
             args.MinPCRLen,args.MaxPCRLen,args.MinIn2AAIdtt,args.MinOut2AAIdtt,args.MinInIdtt,args.MinAllIdtt,args.MaxGapRate,
             args.NestedPrimerDstc,args.OutDir)
    #here will import step4's code