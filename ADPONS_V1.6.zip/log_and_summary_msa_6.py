import time
import os

linesep = os.linesep[0]



def write_log(log_str, out_dir):
    time_out = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    log_path = os.path.join(out_dir,'UPrimer.log')
    if not os.path.isfile(log_path):
        with open(log_path, 'w') as log:
            log_out = time_out + '  UPrimer starts working' + linesep
            log.write(log_out)
    with open(log_path,'a') as log:
        log_out = time_out + '  ' + log_str + linesep
        log.write(log_out)






