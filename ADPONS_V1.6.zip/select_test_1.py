import os
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Blast import NCBIXML
from Bio.SeqRecord import SeqRecord
import glob
import log_and_summary_msa_6 as log
import argparse

linesep = os.linesep


# work_dir = r'E:\PycharmCode\test\taxa1'

class Blast:
    def __init__(self, query, database_source, out_dir):  # query和database_source是绝对路径
        self.query = query
        self.database_source = database_source
        self.out_dir = out_dir
        self.database = os.path.join(out_dir, 'blastdb',
                                     os.path.split(str(self.database_source).replace('.fasta', ''))[1])

    def makeblastdb(self, dbtype):  # 建库在工作路径下的blastdb
        outDB = str(self.database_source).replace('.fasta', '')  # 为了方便后面加后缀
        outDB_path = os.path.join(self.out_dir, 'blastdb', os.path.split(outDB)[1])
        log_in = 'Making blast database: ' + outDB_path
        log.write_log(log_in, self.out_dir)
        if not os.path.isdir(os.path.dirname(outDB_path)):
            os.mkdir(os.path.dirname(outDB_path))

        if dbtype == 'nucl':
            if not os.path.exists(outDB_path + '.nhr') or not os.path.exists(outDB_path + '.nin') or not os.path.exists(
                    outDB_path + '.nsq'):
                command_make_database = "makeblastdb -in " + str(self.database_source) + " -out " + str(
                    outDB_path) + " -dbtype " + str(dbtype)
                print(command_make_database)
                os.system(command_make_database)
            else:
                print("A BLAST DB has existed.")
        elif dbtype == 'prot':
            if not os.path.exists(outDB_path + ".phr") or not os.path.exists(outDB_path + ".pin") or not os.path.exists(
                    outDB_path + ".psq"):
                command_make_database = "makeblastdb -in " + str(self.database_source) + " -out " + str(
                    outDB_path) + " -dbtype " + str(dbtype)
                os.system(command_make_database)
            else:
                print("A BLAST DB has existed.")
        else:
            print('The dbtype is wrong !')

    def blastn(self, outXML_name, num_threads):
        outXML_path = os.path.join(self.out_dir, 'xml', outXML_name)
        log_in = 'Making blastn: ' + outXML_path
        log.write_log(log_in,self.out_dir)
        if not os.path.exists(os.path.dirname(outXML_path)):
            os.mkdir(os.path.dirname(outXML_path))
        if not os.path.exists(outXML_path):
            command_blastn = 'blastn -task blastn -max_hsps 5 -evalue 1E-10 -outfmt 5 -query ' + str(
                self.query) + ' -db ' + str(self.database) + ' -out ' + str(outXML_path) + ' -num_threads ' + str(
                num_threads) + ' -mt_mode 1'
            os.system(command_blastn)
            print('blastn has done')
        else:
            print('A blastn xml has existed')

    def blastx(self, outXML_name, num_threads):
        outXML_path = os.path.join(self.out_dir, 'xml', outXML_name)
        log_in = 'Making blastx: ' + outXML_path
        log.write_log(log_in, self.out_dir)
        if not os.path.exists(os.path.dirname(outXML_path)):
            os.mkdir(os.path.dirname(outXML_path))
        if not os.path.exists(outXML_path):
            command_blastx = 'blastx -task blastx -evalue 1E-10 -outfmt 5 -query ' + str(self.query) + ' -db ' + str(
                self.database) + ' -out ' + str(outXML_path) + ' -num_threads ' + str(num_threads) + ' -mt_mode 1'
            os.system(command_blastx)
            print('blastx has done')
        else:
            print('A blastx xml has existed')

    def tblastn(self, outXML_name, num_threads):
        outXML_path = os.path.join(self.out_dir, 'xml', outXML_name)
        log_in = 'Making tblastn: ' + outXML_path
        log.write_log(log_in, self.out_dir)
        if not os.path.exists(os.path.dirname(outXML_path)):
            os.mkdir(os.path.dirname(outXML_path))
        if not os.path.exists(outXML_path):
            command_tblastn = 'tblastn -task tblastn -evalue 1E-10 -outfmt 5 -query ' + str(self.query) + ' -db ' + str(
                self.database) + ' -out ' + str(outXML_path) + ' -num_threads ' + str(num_threads) + ' -mt_mode 1'
            os.system(command_tblastn)
            print('blastx has done')
        else:
            print('A blastx xml has existed')

class Diamond:
    def __init__(self, query, database_source, out_dir):
        self.query = query
        self.database_source = database_source
        self.out_dir = out_dir
        self.database = os.path.join(out_dir, 'diamonddb',
                                     os.path.split(str(self.database_source).replace('.fasta', '.dmnd'))[1])
    def makediamonddb(self):  # 建库在工作路径下的blastdb
        outDB = str(self.database_source).replace('.fasta', '')  # 为了方便后面加后缀
        outDB_path = os.path.join(self.out_dir, 'diamonddb', os.path.split(outDB)[1])
        log_in = 'Making diamond database: ' + outDB_path
        log.write_log(log_in, self.out_dir)
        if not os.path.isdir(os.path.dirname(outDB_path)):
            os.mkdir(os.path.dirname(outDB_path))

        if not os.path.exists(outDB_path + '.dmnd'):
            command_make_database = "diamond makedb --in " + str(self.database_source) + " -d " + str(
                outDB_path)
            print(command_make_database)
            os.system(command_make_database)
        else:
            print("A diamond DB has existed.")

    def blastx(self, outXML_name,threads):
        outXML_path = os.path.join(self.out_dir, 'xml', outXML_name)
        log_in = 'Making blastx: ' + outXML_path
        log.write_log(log_in, self.out_dir)
        if not os.path.exists(os.path.dirname(outXML_path)):
            os.mkdir(os.path.dirname(outXML_path))
        if not os.path.exists(outXML_path):
            command_tblastn = 'diamond blastx -p '+str(threads)+' -f 5 -q ' + str(self.query) + ' -d ' + str(
                self.database) + ' -o ' + str(outXML_path)
            os.system(command_tblastn)
            print('blastx has done')
        else:
            print('A blastx xml has existed')

def correct_fasta_format(fasta_path):
    records_out = []
    with open(fasta_path) as handle:
        records = SeqIO.parse(handle,format='fasta')
        for record in records:
            description_out = record.description.replace('<','').replace('>','').replace('unknown id','')
            while '  ' in description_out:
                description_out = description_out.replace('  ', ' ')
            if description_out[0] == ' ':
                description_out = description_out[1:]
            record_out = SeqRecord(record.seq, description= description_out,id='unknown id')
            records_out.append(record_out)
            #print(record.description)
    with open(fasta_path,'w') as handle:
        SeqIO.write(records_out,handle,'fasta')

# 筛选长外显子，输入文件全部放入一个文件夹中，infile是外显子fasta文件名，outfile是输出文件名，min_exon_len是筛选阈值，work_dir是exon文件夹所在的目录。
def select_long_exon(infile, outfile, min_exon_len, work_dir,out_dir):
    in_path = os.path.join(work_dir, 'exon', infile)
    out_path = os.path.join(out_dir, 'exon', outfile)  # 创建长外显子
    log_in = 'Selecting the long exon of reference species: ' + out_path
    log.write_log(log_in, out_dir)
    if not os.path.exists(os.path.dirname(out_path)):
        os.mkdir(os.path.dirname(out_path))
    if os.path.isfile(out_path):
        print('Long exon file has existed')
    else:
        with open(out_path, 'w') as fh:
            id_list = []
            for records in SeqIO.parse(in_path, 'fasta'):
                exon_len = len(records.seq)
                if exon_len >= int(min_exon_len) and records.id not in id_list:
                    id_list.append(records.id)
                    SeqIO.write(records, fh, "fasta")
        print(infile + ' cut done!')
    return out_path


# infile是长外显子fasta文件名，outfile是单拷贝长外显子文件名，blast_xml是比对结果
def select_long_single_copy_exon(infile, outfile, blast_xml, cover, similarity, work_dir,out_dir):
    in_path = os.path.join(out_dir, 'exon', infile)
    out_path = os.path.join(out_dir, 'exon', outfile)  # 创建长单拷贝外显子
    log_in = 'Selecting the long single copy exon of reference species: ' + out_path
    log.write_log(log_in, out_dir)
    if os.path.isfile(out_path):
        print('Long exon file has existed')
    xml_path = os.path.join(out_dir, 'xml', blast_xml)
    Dict = SeqIO.to_dict(SeqIO.parse(in_path, "fasta"),
                         key_function=lambda r: r.description)  # 创建字典，后续根据比对结果，输入description输出序列
    if not os.path.isfile(out_path):
        with open(out_path, 'w') as out:
            with open(xml_path) as inxml:
                blast_records = NCBIXML.parse(inxml)
                for blast_record in blast_records:
                    query = str(blast_record.query)  # 根据description判断真的可靠吗
                    query_len = str(blast_record.query_length)
                    alignment_count = 0  # alignment条数
                    q = 0  # fasta条数
                    two_cover = 1
                    two_identify = 1
                    record = None
                    for alignment in blast_record.alignments:
                        alignment_count += 1
                        hsp_count = 0
                        for Hsp in alignment.hsps:
                            hsp_count += 1
                            if alignment_count == 2 and hsp_count == 1:
                                two_identify = float(Hsp.identities) / float(Hsp.align_length)
                                two_cover = float(Hsp.align_length) / float(query_len)
                                break
                    if alignment_count == 1:  # 仅有一条alignment时直接输出
                        record = Dict[query]
                        q = 1
                    elif alignment_count != 1:  # 若有多条alignment，则判断第二个alignment的第一HSP的相似度和覆盖度是否达标。
                        if two_identify > float(similarity) and two_cover > float(cover):
                            pass
                        else:
                            record = Dict[query]
                            q = 1
                    else:
                        pass
                    if q == 1:
                        SeqIO.write(record, out, "fasta")
                        q += 1
                    else:
                        pass
                print('single-copy filter done!')
    else:
        print('There is a single_copy file!')


def select_cds_and_translate(infile, blast_xml, work_dir, refer_sp, out_dir):  # infile是单拷贝长外显子fasta文件名，blast_xml是blastx输出的xml文件
    in_path = os.path.join(out_dir, 'exon', infile)
    xml_path = os.path.join(out_dir, 'xml', blast_xml)
    out_cds_path = os.path.join(out_dir, 'exon', 'cds_' + refer_sp.replace('_exon.fasta', '.fasta'))
    out_peptide_path = os.path.join(out_dir, 'exon', 'peptide_' + refer_sp.replace('_exon.fasta', '.fasta'))
    log_in = 'Selecting the long single copy cds of reference species: ' + out_cds_path
    log.write_log(log_in, out_dir)
    log_in = 'Selecting the long single copy peptide of reference species: ' + out_peptide_path
    log.write_log(log_in, out_dir)
    if not os.path.exists(os.path.dirname(out_cds_path)):
        os.mkdir(os.path.dirname(out_cds_path))
    if not os.path.exists(os.path.dirname(out_peptide_path)):
        os.mkdir(os.path.dirname(out_peptide_path))

    Dict = SeqIO.to_dict(SeqIO.parse(in_path, 'fasta'), key_function=lambda r: r.description)
    if not os.path.exists(out_cds_path):
        with open(out_cds_path, 'w') as cds_out, open(out_peptide_path, 'w') as pep_out, open(xml_path) as fh_xml:
            blast_records = NCBIXML.parse(fh_xml)  # 解析单拷贝长外显子与肽链的blastx结果
            for blast_record in blast_records:
                query = str(blast_record.query)
                align_count = 0
                for alignment in blast_record.alignments:
                    align_count = align_count + 1
                    hsp_count = 0
                    for HSP in alignment.hsps:
                        hsp_count += 1
                        if align_count == 1 and hsp_count == 1:  # 保证输出的是比对分数最高的？
                            frame = HSP.frame[0]  # 确定是是正向还是反向
                            start = int(HSP.query_start)
                            end = int(HSP.query_end)
                            if frame < 0:  # 拨乱反正
                                seq = str(Dict[query].seq[start - 1:end].reverse_complement())
                            else:
                                seq = str(Dict[query].seq[start - 1:end])
                            seq_pep = Seq(seq).translate()  # 翻译，密码表未知
                            if str(seq_pep).count('*') > 1:  # 检查终止密码子
                                # with open('stop_codon_log.txt', 'a') as log:
                                # lo = str(query) + '\t' + str(str(seq_pep).count('*'))
                                # log.write(lo + linesep)#待修改的日志
                                pass
                            else:
                                record_cds = SeqRecord(Seq(seq), description=str(query))
                                record_pep = SeqRecord(seq_pep, description=str(query))
                                SeqIO.write(record_cds, cds_out, 'fasta')
                                SeqIO.write(record_pep, pep_out, 'fasta')
                                break
    else:
        print('CDS file have existed!')

def extract_nucl_seq(fasta_dic,description,frame,start,stop):
    seq_temp = fasta_dic[description].seq
    if frame[0]<0:
        target_seq = str(seq_temp)[start-1:stop]
    else:
        target_seq = str(seq_temp)[start-1:stop]
    return target_seq.upper()

def extract_hitseq(xml_path, fasta_dict, fasta_path):

    if not os.path.exists(os.path.dirname(fasta_path)):
        os.mkdir(os.path.dirname(fasta_path))
    fasta_list = []
    fasta_description_list = []
    if not os.path.exists(fasta_path):
        with open(xml_path) as xml:
            blast_records = NCBIXML.parse(xml)
            for record in blast_records:
                query = str(record.query)
                hit_count = 0
                for alignment in record.alignments:
                    hit_count += 1
                    hsp_count = 0
                    for hsp in alignment.hsps:
                        hsp_count += 1
                        if hsp_count == 1:  #hit_count == 1:
                            start = hsp.query_start
                            stop = hsp.query_end
                            length = ((stop - start) ** 2) ** 0.5 + 1
                            nucl_frame = hsp.frame
                            nucl_pos = query  # 这里获得了核酸序列的染色体位置、起止位置
                            nucl_seq = extract_nucl_seq(fasta_dict, nucl_pos, nucl_frame, start, stop)
                            fasta_description = nucl_pos + '_' + str(start) + '_' + str(stop)
                            fasta_seq = SeqRecord(Seq(nucl_seq), description=fasta_description.replace('  ',''))
                            if fasta_description not in fasta_description_list:
                                fasta_list.append(fasta_seq)
                                fasta_description_list.append(fasta_description)
        SeqIO.write(fasta_list, fasta_path, 'fasta')
        correct_fasta_format(fasta_path)


# species_list输入绝对路径
def pipeline(min_exon_len, number_threads, cover, similarity, species_list_path, out_dir):
    work_dir = os.path.split(species_list_path)[0]  # 自动识别工作文件夹
    with open(species_list_path) as sp_list:
        species = sp_list.readlines()
        refer_sp = species[0].strip()  # 第一行是参考基因组，fasta文件以exon结尾

        long_exon = 'Long_' + str(min_exon_len) + '_' + refer_sp  # long_exon是长外显子的输出文件名
        select_long_exon(refer_sp, long_exon, min_exon_len, work_dir,out_dir)  # 筛选长外显子，输出到原始外显子同一文件夹

        # 建库需要query和database构建文件的绝对路径，下面是blast长外显子和参考基因组
        long_exon_path = os.path.join(out_dir, 'exon', long_exon)
        ref_genome_path = os.path.join(work_dir, 'genome', str(refer_sp.replace('exon.fasta', 'genomic.fasta')))
        outXML_blastn = 'Long_' + str(min_exon_len) + '_blastn_' + refer_sp.replace('_exon.fasta', '_genomic.xml')
        blastn_exon_genome = Blast(long_exon_path, ref_genome_path, out_dir)  # 将长外显子与基因组比对，用于后续排除多拷贝
        blastn_exon_genome.makeblastdb('nucl')
        blastn_exon_genome.blastn(outXML_blastn, number_threads)
        # 输出单拷贝长外显子
        long_single_exon = 'Long_' + str(min_exon_len) + '_single_' + refer_sp
        select_long_single_copy_exon(long_exon, long_single_exon, outXML_blastn, cover, similarity, work_dir, out_dir)
        # 准备把单拷贝长外显子筛选出cds并翻译
        long_single_exon_path = os.path.join(out_dir, 'exon', long_single_exon)
        ref_peptide_path = os.path.join(work_dir, 'peptide', str(refer_sp.replace('exon.fasta', 'pep.fasta')))
        correct_fasta_format(ref_peptide_path)
        outXML_blastx = 'Long_' + str(min_exon_len) + '_blastx_' + refer_sp.replace('exon.fasta', 'pep.xml')
        blastx_exon_peptide = Diamond(long_single_exon_path, ref_peptide_path, out_dir)  # 将单拷贝长外显子与肽链比对，用于得到cds和其翻译肽链
        blastx_exon_peptide.makediamonddb()
        blastx_exon_peptide.blastx(outXML_blastx,number_threads)
        # 开始筛选cds和peptide
        select_cds_and_translate(long_single_exon, outXML_blastx, work_dir, refer_sp,out_dir)
        ref_cds_path = os.path.join(out_dir, 'exon', 'cds_' + refer_sp.replace('_exon.fasta', '.fasta'))
        correct_fasta_format(ref_cds_path)
        ref_cds_pep_path = os.path.join(out_dir, 'exon', 'peptide_' + refer_sp.replace('_exon.fasta', '.fasta'))
        correct_fasta_format(ref_cds_pep_path)
        # 将长单拷贝外显子的翻译肽链和基因组或cds进行tblastn
        log_in = 'Starting extract the hitseq of all species except reference species'
        log.write_log(log_in,out_dir)
        for specie in species[1:]:
            if '_cds' in specie:
                genome_source = os.path.join(work_dir, 'CDS', str(specie.strip()))
                correct_fasta_format(genome_source)
                genome_source_dict = SeqIO.to_dict(SeqIO.parse(genome_source, 'fasta'),
                                                     key_function=lambda i: i.description)
                hitseq_fasta_path = os.path.join(out_dir,'hitseq', str(specie.strip()).replace('.fasta','_hitseq.fasta'))
                outXML_1 = str(specie.strip()).replace('.fasta', '') + '_blastx_' + str(refer_sp).replace('exon.fasta', 'pep.xml')
                outXML_1_path = os.path.join(out_dir,'xml',outXML_1)
                blast_1 = Diamond(genome_source, ref_cds_pep_path, out_dir)
                blast_1.makediamonddb()
                blast_1.blastx(outXML_1,number_threads)
                extract_hitseq(outXML_1_path,genome_source_dict,hitseq_fasta_path)
                log_in = 'One hitseq has been extracted: ' + hitseq_fasta_path
                log.write_log(log_in, out_dir)
            elif '_genomic' in specie:
                genome_source = os.path.join(work_dir, 'genome', str(specie).strip())
                correct_fasta_format(genome_source)
                genome_source_dict = SeqIO.to_dict(SeqIO.parse(genome_source, 'fasta'),
                                                     key_function=lambda i: i.description)
                hitseq_fasta_path = os.path.join(out_dir, 'hitseq', str(specie.strip()).replace('.fasta','_hitseq.fasta'))
                outXML_1 = str(specie.strip()).replace('.fasta', '') + '_blastx_' + str(refer_sp).replace('exon.fasta', 'pep.xml')
                outXML_1_path = os.path.join(out_dir, 'xml', outXML_1)
                blast_1 = Diamond(genome_source, ref_cds_pep_path, out_dir)
                blast_1.makediamonddb()
                blast_1.blastx(outXML_1,number_threads)
                extract_hitseq(outXML_1_path, genome_source_dict, hitseq_fasta_path)
                log_in = 'One hitseq has been extracted: ' + hitseq_fasta_path
                log.write_log(log_in, out_dir)
        # 对长单拷贝pep和hitseq双向blast
        log_in = 'Starting TBlast between reference peptide and each hitseq'
        log.write_log(log_in, out_dir)
        hitseq_path_list = glob.glob(os.path.join(out_dir,'hitseq','*.fasta'))
        #print(hitseq_path_list)
        for hitseq_path in hitseq_path_list:
            outXML_2 = str(refer_sp).replace('exon.fasta', 'pep') + '_tblastn_' + os.path.split(hitseq_path)[1].replace(
                'fasta', 'xml')
            blast_2 = Blast(ref_cds_pep_path, hitseq_path, out_dir)
            blast_2.makeblastdb('nucl')
            blast_2.tblastn(outXML_2, number_threads)

            outXML_3 = os.path.split(hitseq_path)[1].replace('.fasta','') + '_blastx_' + str(refer_sp).replace('exon.fasta', 'pep.xml')
            blast_3 = Blast(hitseq_path,ref_cds_pep_path,out_dir)
            blast_3.makeblastdb('prot')
            blast_3.blastx(outXML_3,number_threads)

    return ref_cds_pep_path, ref_cds_path

# print(os.path.split(work_dir)[0])

# select_long_exon('Drosophila_melanogaster_exon.fasta', 'test_out.fasta', 600, work_dir)
# print_seq_len('test_out.fasta')
#pipeline(600, 5, 0.3, 0.5, r'E:\PycharmCode\test\taxa1\Diptera_species.txt',r'E:\PycharmCode\test\taxa1_result')
# 输入外显子最小长度、blast线程数、单拷贝的最大覆盖度、单拷贝最大相似度、物种表

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="python UPrimer_V2.py --list -L")
    parser.add_argument("--list", "-L", help="Your species list", required=True)
    parser.add_argument("--OutDir", "-D", help="Your output directory", required=True)
    parser.add_argument("--MinExonLen", "-E", help="Reference species's min length of single copy peptide", default=int(300))
    parser.add_argument("--threads", "-T", help="Threads used in Blast", default=int(15))
    parser.add_argument("--cover", "-C", help="A criteria when judging single copy exon", default=float(0.3))
    parser.add_argument("--similarity", "-S", help="A criteria when judging single copy exon", default=float(0.5))

    args = parser.parse_args()
    pipeline(args.MinExonLen,args.threads,args.cover,args.similarity,args.list,args.OutDir)