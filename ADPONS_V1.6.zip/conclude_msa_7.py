import os
import remove_rogue_and_quality_control_4 as rm7qc
import glob
import pandas as pd
import argparse

def return_msa_info(fasta_path):
    fasta_info_dict = rm7qc.return_identity_info_dict(fasta_path)
    ingroup_count = 1
    outgroup_count = 0
    for key in fasta_info_dict.keys():
        if 'cds' in key:
            outgroup_count += 1
        if 'genomic' in key:
            ingroup_count += 1
    msa_len = len(fasta_info_dict['total_common_seq'])-1
    msa_gap_rate = fasta_info_dict['total_gap_rate'][-1]
    msa_idtt = fasta_info_dict['total_identity'][-1]
    msa_gene = list(fasta_info_dict.keys())[0]
    out_list = [msa_gene,ingroup_count,outgroup_count,msa_gap_rate,msa_idtt,msa_len]
    return out_list

def pipeline(out_dir):
    msa_fold_list = [os.path.join(out_dir,'aligned_target_cds_without_rogue'), os.path.join(out_dir,'aligned_target_peptide_without_rogue')]
    out_index = ['peptide','ingroup_count','outgroup_count','gap_rate','msa_identity','msa_length']
    for fold_path in msa_fold_list:
        out_dict = {}
        fasta_list = glob.glob(os.path.join(fold_path,'*.fasta'))
        for fasta_path in fasta_list:
            out_dict[os.path.split(fasta_path)[1]] = return_msa_info(fasta_path)
        out_df = pd.DataFrame(out_dict, index=out_index).transpose().sort_values(by='msa_identity', ascending=False)
        if 'cds' in fold_path:
            out_path = os.path.join(out_dir, 'MSA_cds_info.csv')
        else:
            out_path = os.path.join(out_dir, 'MSA_peptide_info.csv')
        out_df.to_csv(out_path)



#out_dir = r'E:\PycharmCode\test\taxa1_result'
#pipeline(out_dir)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="python UPrimer_V2.py --list -L")
    parser.add_argument("--OutDir", "-D", help="Your output directory", required=True)

    args = parser.parse_args()
    pipeline(args.OutDir)

