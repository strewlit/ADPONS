import os
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Blast import NCBIXML
from Bio.SeqRecord import SeqRecord
import pandas as pd
import log_and_summary_msa_6 as log
import argparse


# 输出一个字典{query:[subject,...,...,...],...,...,...}
def make_query_subject_dic(xml):
    out_dic = dict()
    with open(xml) as xml:
        records = NCBIXML.parse(xml)
        for record in records:
            subject_list = set()
            for alignment in record.alignments:
                subject_list.add(alignment.hit_def)
            out_dic[record.query] = subject_list
    return out_dic

#根据blastx和tblastn的xml文件，返回一个符合双向blast要求的peptide集合
def judge_blast_and_return_PepList(blastx_xml, tblastn_xml):
    blastx_keys = blastx_xml.keys()
    tblastn_keys = tblastn_xml.keys()
    pep_out = list(tblastn_keys)
    for pep in tblastn_keys:
        if len(list(tblastn_xml[pep])) > 0:
            tblastn_best_sbjct = list(tblastn_xml[pep])[0]
            if tblastn_best_sbjct in blastx_keys and len(list(blastx_xml[tblastn_best_sbjct])) > 0:
                blastx_best_sbjct = list(blastx_xml[tblastn_best_sbjct])[0]
                if blastx_best_sbjct != pep:
                    pep_out.remove(pep)
    return pep_out

#根据fasta字典、frame和染色体位置抽出用于比对的目标核酸序列
def extract_nucl_seq(fasta_dic,description,frame,start,stop):
    seq_temp = fasta_dic[description].seq
    if frame[1]<0:
        target_seq = str(fasta_dic[description].seq[start-1:stop].reverse_complement())
    else:
        target_seq = str(seq_temp)[start-1:stop]
    return target_seq.upper()

#在一个tblastn，或是说一个物种中，query是长单拷贝序列，subject是染色体，输出一个字典{query:[nucl_seq,pep_seq]}，如果query没有匹配到，就是对应None。该字典用于填充dataframe
def return_NuclSeq_PepSeq_dic(pep_list, tblastn_xml, fasta_dict):
    dic_out = dict()
    with open(tblastn_xml) as xml:
        records = NCBIXML.parse(xml)
        for record in records:
            if record.query in pep_list:
                alignment_count = 0
                temp = 'None'
                for alignment in record.alignments:
                    alignment_count += 1
                    hsp_count = 0
                    for hsp in alignment.hsps:
                        hsp_count += 1
                        if hsp_count == 1 and alignment_count == 1:
                            start = hsp.sbjct_start
                            stop = hsp.sbjct_end
                            length = ((stop-start)**2)**0.5 + 1
                            nucl_frame = hsp.frame
                            nucl_pos = alignment.hit_def    #这里获得了核酸序列的染色体位置、起止位置
                            nucl_seq = extract_nucl_seq(fasta_dict,nucl_pos,nucl_frame,start,stop)
                            temp = [nucl_seq,str(hsp.sbjct).replace('-','')]        #记得去除tblastn的gap
                dic_out[record.query] = temp
            else:
                dic_out[record.query] = 'None'
    return dic_out

#建立一个dataframe，index是长单拷贝片段的名字，colname是物种，内容是列表[hit_seq,hit_pep]或None（表示没匹配到）
def create_pep_info_dataframe(species_list_path, ref_cds_pep_path,out_dir):
    peptide_list = []   #长单拷贝片段名字列表
    for record in SeqIO.parse(open(ref_cds_pep_path), 'fasta'):
        peptide_list.append(record.description)
    gene_df_path = os.path.join(out_dir, 'pep_info.csv')
    if not os.path.exists(gene_df_path):
        gene_df = pd.DataFrame(index=peptide_list)  #建立dataframe
        with open(species_list_path) as sp_list:
            species = sp_list.readlines()
            ref_sp = species[0].strip().replace('exon.fasta', 'pep')
            for specie in species[1:]:
                specie = specie.strip()
                specie_NuclSeq_path = os.path.join(out_dir, 'hitseq', specie.replace('.fasta','_hitseq.fasta'))
                print(specie_NuclSeq_path)
                log_in = 'Extracting the orthologous seq of this hitseq: ' + specie_NuclSeq_path
                log.write_log(log_in,out_dir)
                specie_NuclSeq_dic = SeqIO.to_dict(SeqIO.parse(specie_NuclSeq_path, 'fasta'), key_function=lambda i: i.description)     #以description为键，把基因组的fasta文件变成字典
                specie = specie.strip().replace('.fasta', '_hitseq')
                blastx_xml = os.path.join(out_dir, 'xml', specie + '_blastx_' + ref_sp + '.xml')
                tblastn_xml = os.path.join(out_dir, 'xml', ref_sp + '_tblastn_' + specie + '.xml')
                blastx_xml_dic = make_query_subject_dic(blastx_xml)     #该字典用于判断双向blast
                tblastn_xml_dic = make_query_subject_dic(tblastn_xml)
                OneToOne_peptide = judge_blast_and_return_PepList(blastx_xml_dic, tblastn_xml_dic)      #对于这个物种中，这个peptide表就是符合双向blast的所有peptide
                specie_info_dic = return_NuclSeq_PepSeq_dic(OneToOne_peptide, tblastn_xml,specie_NuclSeq_dic)   #生成一个物种往dataframe填充的字典，键就是index，即长单拷贝片段名称
                # print(specie_info_dic)
                gene_df[str(specie)] = pd.Series(specie_info_dic)
        # print(gene_df)
        gene_df.to_csv(gene_df_path, index=True)    #默认写在工作目录根目录
    else:   #因为内容物是列表，读取的时候不能直接识别，所以一定要转换
        gene_df = pd.read_csv(gene_df_path, index_col=0)
        for index in gene_df.index:
            for col in gene_df.columns:
                if gene_df.loc[index][col] != 'None':
                    gene_df.loc[index][col] = eval(gene_df.loc[index][col].replace('[','').replace(']',''))
                    #print(gene_df.loc[index][col])
                    #print(len(gene_df.loc[index][col]))
                    #gene_df.loc[index][col] = gene_df.loc[index][col].split(', ')
    return gene_df

def select_target_gene(dataframe, min_len, min_ingroup, min_outgroup,out_dir):
    log_in = 'Screening for qualified genes roughly'
    log.write_log(log_in,out_dir)
    # 将短的去掉
    for index in dataframe.index:
        for col in dataframe.columns:
            # print(dataframe.loc[index][col])
            if dataframe.loc[index][col] != 'None':
                length = len(dataframe.loc[index][col][1])
                if length**2 < min_len**2 or '*' in dataframe.loc[index][col][1]:
                    dataframe.loc[index][col] = 'None'
    # 将含有最小内外类群数量要求的基因列出来
    gene_list = list(dataframe.index)
    for index in dataframe.index:
        ingroup_count = 0
        outgroup_count = 0
        for col in dataframe.columns:
            if 'genomic' in col:
                if dataframe.loc[index][col] != 'None':
                    ingroup_count += 1
            if 'cds' in col:
                if dataframe.loc[index][col] != 'None':
                    outgroup_count += 1
        if ingroup_count < min_ingroup or outgroup_count < min_outgroup:
            gene_list.remove(index)
    return gene_list

def pipeline(species_list_path, ref_cds_pep_path, ref_cds_path,out_dir):
    pep_info_df = create_pep_info_dataframe(species_list_path, ref_cds_pep_path,out_dir)
    # print(pep_info_df.index)
    # print(pep_info_df.columns)
    selected_gene_list = select_target_gene(pep_info_df, 100, 1, 1, out_dir)
    selected_gene_info_df = pep_info_df.loc[selected_gene_list]
    selected_gene_info_df_path = os.path.join(out_dir,'selected_pep_info.csv')
    if not os.path.exists(selected_gene_info_df_path):
        selected_gene_info_df.to_csv(selected_gene_info_df_path,index = True)
    #输出蛋白质序列
    if not os.path.exists(os.path.join(out_dir,'target_peptide')):
        os.mkdir(os.path.join(out_dir,'target_peptide'))
    count = 0
    ref_sp_pep_dic = SeqIO.to_dict(SeqIO.parse(ref_cds_pep_path, 'fasta'), key_function=lambda i: i.description)
    #print(ref_sp_dic.keys())
    for index in selected_gene_info_df.index:
        count += 1
        fasta_path = os.path.join(out_dir,'target_peptide',str(count)+'.fasta')
        if not os.path.exists(fasta_path):
            records = []
            records.append(ref_sp_pep_dic[index])
            for col in selected_gene_info_df.columns:
                if selected_gene_info_df.loc[index][col] != 'None':
                    record_seq = Seq(selected_gene_info_df.loc[index][col][1])
                    record = SeqRecord(record_seq,description=col)
                    records.append(record)
            SeqIO.write(records,fasta_path,'fasta')
    #输出核酸序列
    if not os.path.exists(os.path.join(out_dir,'target_cds')):
        os.mkdir(os.path.join(out_dir,'target_cds'))
    count = 0
    ref_sp_nucl_dic = SeqIO.to_dict(SeqIO.parse(ref_cds_path, 'fasta'), key_function=lambda i: i.description)
    # print(ref_sp_dic.keys())
    for index in selected_gene_info_df.index:
        count += 1
        fasta_path = os.path.join(out_dir, 'target_cds', str(count) + '.fasta')
        if not os.path.exists(fasta_path):
            records = []
            records.append(ref_sp_nucl_dic[index])
            for col in selected_gene_info_df.columns:
                if selected_gene_info_df.loc[index][col] != 'None':
                    record_seq = Seq(selected_gene_info_df.loc[index][col][0])
                    record = SeqRecord(record_seq, description=col)
                    records.append(record)
            SeqIO.write(records, fasta_path, 'fasta')


#pipeline(r'E:\PycharmCode\test\taxa1\Diptera_species.txt', r'E:\PycharmCode\test\taxa1_result\exon\peptide_Drosophila_melanogaster.fasta', r'E:\PycharmCode\test\taxa1_result\exon\cds_Drosophila_melanogaster.fasta',r'E:\PycharmCode\test\taxa1_result')
#输入物种表路径、单拷贝peptide fasta文件路径，单拷贝cds fasta文件路径

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="python UPrimer_V2.py --list -L")
    parser.add_argument("--list", "-L", help="Your species list", required=True)
    parser.add_argument("--OutDir", "-D", help="Your output directory", required=True)
    parser.add_argument("--RefPep", "-P", help="Your reference peptide path", required=True)
    parser.add_argument("--RefCds", "-C", help="Your reference cds path", required=True)

    args = parser.parse_args()
    pipeline(args.list,args.RefPep,args.RefCds,args.OutDir)
    #your xml folder and hitseq folder should put into out_dir